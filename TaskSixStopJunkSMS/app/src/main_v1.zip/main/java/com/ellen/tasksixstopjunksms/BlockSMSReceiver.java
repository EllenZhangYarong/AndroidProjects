package com.ellen.tasksixstopjunksms;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsMessage;

public class BlockSMSReceiver extends BroadcastReceiver {

    public BlockSMSReceiver() {
    }

    @Override
    public void onReceive(Context context, Intent intent) {

        System.out.println("已经可以接收广播了！");

//        String action = intent.getAction().toString();
//        if(action.equals(Intent.ACTION_BOOT_COMPLETED)){
//            System.out.println("OnReceiver is already start !!!!!!!!");
//
//        }else {
//            Bundle extras = intent.getExtras();
//            if(extras==null){
//                return;
//            }
//
//            final Object[] pdusSMS = (Object[]) intent.getExtras().get("pdus");
//
//            for (Object pdu : pdusSMS) {
//                SmsMessage smsMessage = SmsMessage.createFromPdu((byte[]) pdu);
//                final String number = smsMessage.getOriginatingAddress();
//                final String message = smsMessage.getMessageBody();
//                System.out.println("The sender is ----------\n" + number + "\n---------------");
//                System.out.println("The message is ---------\n" + message + "\n--------------");
//                //final String badNumber = JunkSMS.SENTNUMBER;
//                if (number.equals("10086")) {
//                    System.out.println("---The sender is ----------\n" + number + "\n---------------");
//                    System.out.println("---The message is ---------\n" + message + "\n--------------");
//                    abortBroadcast();
//                    // Save this message into table JunkSMS
//                }
//            }
//        }
    }


}

package com.ellen.tasksixstopjunksms;

import android.database.Cursor;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by ellen on 15/11/23.
 */
public class DatabaseTools {
    /*private ArrayList<HashMap<String, String>> list;
    private Cursor cursor = null;
    private ArrayList<HashMap<String, String>> getBadNumber() {
        list = new ArrayList<HashMap<String, String>>();
        cursor = getContentResolver().query(JunkSMS.JUNKSMS_URI, null, null, null, null);
        while (cursor.moveToNext()) {
            HashMap<String, String> mapJunkSMS = new HashMap<>();
            sentNumber = cursor.getString(cursor.getColumnIndex(JunkSMS.SENTNUMBER));
            smsContent = cursor.getString(cursor.getColumnIndex(JunkSMS.SMSCONTENT));
            receiveTime = cursor.getString(cursor.getColumnIndex(JunkSMS.RECEIVEDTIME));
            mapJunkSMS.put("sentNumber", sentNumber);
            mapJunkSMS.put("smsContent", smsContent);
            mapJunkSMS.put("receiveTime", receiveTime);
            list.add(mapJunkSMS);

        }
        cursor.close();

        return list;
    }
    private ArrayList<HashMap<String, String>> getKeyWords() {
        list = new ArrayList<HashMap<String, String>>();
        cursor = getContentResolver().query(JunkSMS.JUNKSMS_URI, null, null, null, null);
        while (cursor.moveToNext()) {
            HashMap<String, String> mapJunkSMS = new HashMap<>();
            sentNumber = cursor.getString(cursor.getColumnIndex(JunkSMS.SENTNUMBER));
            smsContent = cursor.getString(cursor.getColumnIndex(JunkSMS.SMSCONTENT));
            receiveTime = cursor.getString(cursor.getColumnIndex(JunkSMS.RECEIVEDTIME));
            mapJunkSMS.put("sentNumber", sentNumber);
            mapJunkSMS.put("smsContent", smsContent);
            mapJunkSMS.put("receiveTime", receiveTime);
            list.add(mapJunkSMS);

        }
        cursor.close();

        return list;
    }*/
}
